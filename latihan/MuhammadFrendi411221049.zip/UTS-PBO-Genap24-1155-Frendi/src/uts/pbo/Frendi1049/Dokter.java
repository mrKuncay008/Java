package uts.pbo.Frendi1049;


public class Dokter {
    String nama;
    String jenis;
    int tarif;

    public Dokter(String jenis, String umum, int tarif) {
        this.nama = nama;
        this.jenis = jenis;
        this.tarif = tarif;
    }

}
