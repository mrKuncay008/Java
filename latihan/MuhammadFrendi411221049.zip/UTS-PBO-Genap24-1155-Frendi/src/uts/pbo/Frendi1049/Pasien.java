package uts.pbo.Frendi1049;

public class Pasien {
    String kodePasien;
    String namaPasien;
    String emailPasien;
    
    public Pasien(String kodePasien, String nama, String email) {
        this.kodePasien = kodePasien;
        this.namaPasien = nama;
        this.emailPasien = email;
    }
}
